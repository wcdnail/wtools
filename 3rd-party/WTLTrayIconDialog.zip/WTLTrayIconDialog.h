// WTLTrayIconDialog.h
