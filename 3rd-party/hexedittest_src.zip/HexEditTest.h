// HexEditTest.h
