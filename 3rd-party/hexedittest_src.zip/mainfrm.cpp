// MainFrm.cpp : implmentation of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "AboutDlg.h"
#include "HexEditor.h"
#include "MainFrm.h"


BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
   if( CFrameWindowImpl<CMainFrame>::PreTranslateMessage(pMsg) ) return TRUE;
   return m_view.PreTranslateMessage(pMsg);
}

BOOL CMainFrame::OnIdle()
{
   UIEnable(ID_EDIT_COPY, m_view.CanCopy());
   UIEnable(ID_EDIT_UNDO, m_view.CanUndo());
   UISetCheck(ID_DATASIZE_BYTE, m_view.GetDataSize() == 1);
   UISetCheck(ID_DATASIZE_WORD, m_view.GetDataSize() == 2);
   UISetCheck(ID_DATASIZE_DWORD, m_view.GetDataSize() == 4);
   UIUpdateToolBar();
   return FALSE;
}

LRESULT CMainFrame::OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
   CreateSimpleToolBar();

   CreateSimpleStatusBar();

   m_hWndClient = m_view.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN, WS_EX_CLIENTEDGE);
   //m_view.SetFilename("C:\\temp\\bintest.obj");
   //m_view.SetDisplayOptions(FALSE, TRUE, FALSE);
   //SIZE sz = { 20, 20 }; m_view.SetMargins(sz); sz = m_view.GetMargins();
   //m_view.SetReadOnly();
   m_view.SetDataSize(1);

   UIAddToolBar(m_hWndToolBar);
   UISetCheck(ID_VIEW_TOOLBAR, 1);
   UISetCheck(ID_VIEW_STATUS_BAR, 1);

   // register object for message filtering and idle updates
   CMessageLoop* pLoop = _Module.GetMessageLoop();
   ATLASSERT(pLoop != NULL);
   pLoop->AddMessageFilter(this);
   pLoop->AddIdleHandler(this);

   return 0;
}

LRESULT CMainFrame::OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
   PostMessage(WM_CLOSE);
   return 0;
}

LRESULT CMainFrame::OnFileOpen(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
   TCHAR szPath[MAX_PATH];
   ::GetTempPath(MAX_PATH, szPath);
   LPCTSTR lpcstrFilter = 
      _T("All Files (*.*)\0*.*\0")
      _T("");
   // Open file
   CFileDialog dlg(TRUE, _T("dat"), _T(""), OFN_EXPLORER | OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, lpcstrFilter);
   dlg.m_ofn.lpstrInitialDir = szPath;
   if( dlg.DoModal() != IDOK ) return 0;
   m_view.SetFilename(dlg.m_ofn.lpstrFile);
   return 0;
}

LRESULT CMainFrame::OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
   BOOL bVisible = !::IsWindowVisible(m_hWndToolBar);
   ::ShowWindow(m_hWndToolBar, bVisible ? SW_SHOWNOACTIVATE : SW_HIDE);
   UISetCheck(ID_VIEW_TOOLBAR, bVisible);
   UpdateLayout();
   return 0;
}

LRESULT CMainFrame::OnViewStatusBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
   BOOL bVisible = !::IsWindowVisible(m_hWndStatusBar);
   ::ShowWindow(m_hWndStatusBar, bVisible ? SW_SHOWNOACTIVATE : SW_HIDE);
   UISetCheck(ID_VIEW_STATUS_BAR, bVisible);
   UpdateLayout();
   return 0;
}

LRESULT CMainFrame::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
   CAboutDlg dlg;
   dlg.DoModal();
   return 0;
}

LRESULT CMainFrame::OnDataSizeChange(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
   int iSize = 1;
   if( wID == ID_DATASIZE_WORD ) iSize = 2;
   if( wID == ID_DATASIZE_DWORD ) iSize = 4;
   m_view.SetDataSize(iSize);
   return 0;
}

