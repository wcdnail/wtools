// PhotoThing.h
