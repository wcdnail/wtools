// ChildFrm.h : interface of the CChildFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDFRM_H__9FDEBBE3_2636_4628_9954_1C37AC7D0BFE__INCLUDED_)
#define AFX_CHILDFRM_H__9FDEBBE3_2636_4628_9954_1C37AC7D0BFE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CChildFrame : public CMDIChildWindowImpl<CChildFrame>
{
public:
   DECLARE_FRAME_WND_CLASS(NULL, IDR_MDICHILD)

   CSourceView m_view;

   virtual void OnFinalMessage(HWND /*hWnd*/)
   {
      delete this;
   }

   BEGIN_MSG_MAP(CChildFrame)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_FORWARDMSG, OnForwardMsg)
      CHAIN_CLIENT_COMMANDS()
      CHAIN_MSG_MAP(CMDIChildWindowImpl<CChildFrame>)
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
   {
      m_hWndClient = m_view.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_HSCROLL | WS_VSCROLL | ES_AUTOHSCROLL | ES_AUTOVSCROLL | ES_MULTILINE | ES_NOHIDESEL, WS_EX_CLIENTEDGE);
      bHandled = FALSE;
      return 1;
   }
   LRESULT OnForwardMsg(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
   {
      LPMSG pMsg = (LPMSG)lParam;
      if( CMDIChildWindowImpl<CChildFrame>::PreTranslateMessage(pMsg) )
         return TRUE;
      return m_view.PreTranslateMessage(pMsg);
   }
};


#endif // !defined(AFX_CHILDFRM_H__9FDEBBE3_2636_4628_9954_1C37AC7D0BFE__INCLUDED_)
