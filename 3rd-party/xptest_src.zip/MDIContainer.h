#if !defined(AFX_MDICONTAINER_H__20020426_0903_1B62_2BDF_0080AD509054__INCLUDED_)
#define AFX_MDICONTAINER_H__20020426_0903_1B62_2BDF_0080AD509054__INCLUDED_

#pragma once

/////////////////////////////////////////////////////////////////////////////
// A container window for the MDI Client with tabbed child selection
//
// Written by Bjarke Viksoe (bjarke@viksoe.dk)
// Copyright (c) 2002 Bjarke Viksoe.
//
// This code may be used in compiled form in any way you desire. This
// file may be redistributed by any means PROVIDING it is 
// not sold for profit without the authors written consent, and 
// providing that this notice and the authors name is included. 
//
// This file is provided "as is" with no expressed or implied warranty.
// The author accepts no liability if it causes any damage to you or your
// computer whatsoever. It's free, so don't hassle me about it.
//
// Beware of bugs.
//

class CMDIContainer : 
   public CWindowImpl<CMDIContainer>
{
public:
   CContainedWindow m_wndMDIClient;
   CDotNetTabCtrl m_ctrlTab;

   CMDIContainer() :
      m_wndMDIClient(this, 1)
   {
   }
   ~CMDIContainer()
   {
      if( m_wndMDIClient.IsWindow() )
/*scary!*/   m_wndMDIClient.UnsubclassWindow();
   }

   // Operations
   
   void SetMDIClient(HWND hWnd)
   {
      m_wndMDIClient.SubclassWindow(hWnd);
   }

   // Message map and handler

   BEGIN_MSG_MAP(CMDIContainer)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_SIZE, OnSize)
      NOTIFY_CODE_HANDLER(TCN_SELCHANGE, OnSelChange)
      REFLECT_NOTIFICATIONS()
   ALT_MSG_MAP(1)      // MDI client messages
      MESSAGE_HANDLER(WM_PARENTNOTIFY, OnParentNotify)
      MESSAGE_HANDLER(WM_MDISETMENU, OnMDISetMenu)
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      LRESULT lRes = DefWindowProc();
      SetFont( AtlGetDefaultGuiFont() );
      // Create the tab control
      m_ctrlTab.Create(m_hWnd, rcDefault, NULL, WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS);
      m_ctrlTab.SetExtendedStyle(0, TCS_EX_SELHIGHLIGHT | TCS_EX_FLATSEPARATORS);
      return lRes;
   };
   LRESULT OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      UpdateLayout();
      return 0;
   };
   LRESULT OnSelChange(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)
   {
      // Someone clicked on a tab...
      int idx = m_ctrlTab.GetCurSel();
      if( idx >= 0 ) {
         TCITEM tci = { 0 };
         tci.mask = TCIF_PARAM;
         m_ctrlTab.GetItem(idx, &tci);
         m_wndMDIClient.SendMessage(WM_MDIACTIVATE, (WPARAM) tci.lParam);
      }
      return 0;
   }

   // MDI client messages

   LRESULT OnParentNotify(UINT /*uMsg*/, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      switch( LOWORD(wParam) ) {
      case WM_CREATE:
         {
            HWND hWnd = (HWND) lParam;
            // Get tab text and create new tab
            int nLen = ::GetWindowTextLength(hWnd) + 1;
            LPTSTR pszText = (LPTSTR) _alloca(nLen*sizeof(TCHAR));
            ::GetWindowText(hWnd, pszText, nLen);
            TCITEM tci = { 0 };
            tci.mask = TCIF_TEXT | TCIF_PARAM;
            tci.lParam = lParam;
            tci.pszText = pszText;
            m_ctrlTab.InsertItem(m_ctrlTab.GetItemCount(), &tci);
            UpdateLayout();
            // This implementation maximizes the view at creation...
            m_wndMDIClient.SendMessage(WM_MDIMAXIMIZE, (WPARAM) hWnd, 0);
         }
         break;
      case WM_DESTROY:
         {
            TCITEM tci = { 0 };
            tci.mask = TCIF_PARAM;
            tci.lParam = lParam;
            int idx = m_ctrlTab.FindItem(&tci);
            if( idx >= 0 ) m_ctrlTab.DeleteItem(idx);
            UpdateLayout();
         }
         break;
      }
      bHandled = FALSE; // MDI stuff relies on this, so...
      return 0;
   }
   LRESULT OnMDISetMenu(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
   {
      // Is getting triggered by child activations as well...
      UpdateLayout();
      bHandled = FALSE;
      return 0;
   }

   // Impementation

   void UpdateLayout()
   {
      _SelectActiveChild();

      RECT rc;
      GetClientRect(&rc);
      // Place tab control in frame if populated
      if( m_ctrlTab.GetItemCount() > 0 ) {
         int cy = ::GetSystemMetrics(SM_CYMENUSIZE) + 6;
         RECT rcTab = { rc.left, rc.top, rc.right, rc.top + cy };
         m_ctrlTab.SetWindowPos(NULL, &rcTab, SWP_SHOWWINDOW | SWP_NOZORDER | SWP_NOACTIVATE);
         rc.top += cy;
      }
      else {
         m_ctrlTab.ShowWindow(SW_HIDE);
      }
      // The MDI Client goes below
      if( m_wndMDIClient.IsWindow() ) {
         ::MapWindowPoints(m_hWnd, m_wndMDIClient.GetParent(), (LPPOINT) &rc, 2);
         m_wndMDIClient.SetWindowPos(NULL, &rc, SWP_NOZORDER | SWP_NOACTIVATE);
      }
   }

   // Implementation

   void _SelectActiveChild()
   {
      // Select the active MDI child tab
      if( !m_wndMDIClient.IsWindow() ) return;
      BOOL bMaximized;
      HWND hWndActive = (HWND) m_wndMDIClient.SendMessage(WM_MDIGETACTIVE, 0, (LPARAM) &bMaximized);
      TCITEM tci = { 0 };
      tci.mask = TCIF_PARAM;
      tci.lParam = (LPARAM) hWndActive;
      int idx = m_ctrlTab.FindItem(&tci);
      if( idx >= 0 ) m_ctrlTab.SetCurSel(idx);
   }
};


#endif // !defined(AFX_MDICONTAINER_H__20020426_0903_1B62_2BDF_0080AD509054__INCLUDED_)

