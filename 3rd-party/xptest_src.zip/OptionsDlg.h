#if !defined(AFX_OPTIONSDLG_H__20020501_2A82_72E5_F155_0080AD509054__INCLUDED_)
#define AFX_OPTIONSDLG_H__20020501_2A82_72E5_F155_0080AD509054__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPropertyPage1 : public CDialogImpl<CPropertyPage1>
{
public:
   enum { IDD = IDD_PREFS1 };

   DECLARE_EMPTY_MSG_MAP()
};


class CPropertyPage2 : public CDialogImpl<CPropertyPage2>
{
public:
   enum { IDD = IDD_PREFS2 };

   CPropertyListCtrl m_ctrlList;

   BEGIN_MSG_MAP(CPropertyPage2)
      MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
      REFLECT_NOTIFICATIONS()
   END_MSG_MAP()

   LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      m_ctrlList.SubclassWindow(GetDlgItem(IDC_LIST));
      m_ctrlList.SetExtendedListStyle(PLS_EX_CATEGORIZED | PLS_EX_XPLOOK);
      m_ctrlList.AddItem( PropCreateCategory(_T("GridSize")) );
      m_ctrlList.AddItem( PropCreateSimple(_T("ShowGrid"), true) );
      m_ctrlList.AddItem( PropCreateSimple(_T("SnapToGrid"), true) );
      return TRUE;
   }
};


class COptionsDlg : public CDialogImpl<COptionsDlg>
{
public:
   enum { IDD = IDD_OPTIONS };

   CTreeViewCtrl m_ctrlTree;
   CImageListCtrl m_Images;
   CDlgContainerCtrl m_ctrlContainer;
   CPropertyPage1 m_view1;
   CPropertyPage2 m_view2;

   BEGIN_MSG_MAP(COptionsDlg)
      MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
      COMMAND_ID_HANDLER(IDOK, OnCloseCmd)
      COMMAND_ID_HANDLER(IDCANCEL, OnCloseCmd)
      NOTIFY_CODE_HANDLER(TVN_ITEMEXPANDED, OnItemExpanded)
      NOTIFY_CODE_HANDLER(TVN_SELCHANGED, OnItemSelected)
   END_MSG_MAP()

   LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      CenterWindow(GetParent());

      m_Images.Create(IDB_OPTIONSTREE, 16, 1, RGB(255,0,255));
      m_ctrlTree = GetDlgItem(IDC_TREE);
      m_ctrlTree.SetImageList(m_Images, TVSIL_NORMAL);

      HTREEITEM hRoot;
      hRoot = m_ctrlTree.InsertItem(_T("Environment"), 0, 0, TVI_ROOT, TVI_LAST);
      m_ctrlTree.InsertItem(TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM, _T("General"), 3, 2, 0, 0, 0, hRoot, TVI_LAST);
      m_ctrlTree.InsertItem(TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM, _T("Documents"), 3, 2, 0, 0, 1, hRoot, TVI_LAST);
      m_ctrlTree.Expand(hRoot);
      hRoot = m_ctrlTree.InsertItem(_T("Windows Form Designer"), 0, 0, TVI_ROOT, TVI_LAST);
      m_ctrlTree.InsertItem(TVIF_TEXT | TVIF_IMAGE | TVIF_SELECTEDIMAGE | TVIF_PARAM, _T("General"), 3, 2, 0, 0, 1, hRoot, TVI_LAST);
      m_ctrlTree.Expand(hRoot);

      m_ctrlContainer.SubclassWindow(GetDlgItem(IDC_PLACEHOLDER));
      m_view1.Create(m_ctrlContainer);
      m_view2.Create(m_ctrlContainer);
      m_ctrlContainer.AddItem(m_view1);
      m_ctrlContainer.AddItem(m_view2);

      m_ctrlTree.SelectItem(m_ctrlTree.GetRootItem());

      return TRUE;
   }
   LRESULT OnCloseCmd(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      EndDialog(wID);
      return 0;
   }
   LRESULT OnItemExpanded(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled)
   {
      LPNMTREEVIEW lpnmtv = (LPNMTREEVIEW) pnmh;
      HTREEITEM hChild = m_ctrlTree.GetChildItem(lpnmtv->itemNew.hItem);
      if( hChild ) {
         TVITEM item = { 0 };
         item.hItem = lpnmtv->itemNew.hItem;
         item.mask = TVIF_IMAGE;
         item.iImage = item.iSelectedImage = lpnmtv->action == TVE_EXPAND ? 1 : 0;
         m_ctrlTree.SetItem(&item);
         if( lpnmtv->action == TVE_EXPAND ) m_ctrlTree.SelectItem(hChild);
      }
      bHandled = FALSE;
      return 0;
   }
   LRESULT OnItemSelected(int /*idCtrl*/, LPNMHDR pnmh, BOOL& bHandled)
   {
      LPNMTREEVIEW lpnmtv = (LPNMTREEVIEW) pnmh;
      HTREEITEM hChild = m_ctrlTree.GetChildItem(lpnmtv->itemNew.hItem);
      if( hChild == NULL ) {
         int iPage = (int) m_ctrlTree.GetItemData(lpnmtv->itemNew.hItem);
         m_ctrlContainer.SetCurSel(iPage);
      }
      bHandled = FALSE;
      return 0;
   }
};


#endif // !defined(AFX_OPTIONSDLG_H__20020501_2A82_72E5_F155_0080AD509054__INCLUDED_)
