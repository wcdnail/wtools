#if !defined(AFX_PROPERTYVIEW_H__20020427_21FD_35B8_BD11_0080AD509054__INCLUDED_)
#define AFX_PROPERTYVIEW_H__20020427_21FD_35B8_BD11_0080AD509054__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPropertyView : 
   public CDialogImpl<CPropertyView>,
   public CDialogResize<CPropertyView>
{
public:
   enum { IDD = IDD_PROPERTYVIEW };

   CToolBarXPCtrl m_ctrlToolbar;
   CPropertyListCtrl m_ctrlList;

   BEGIN_MSG_MAP(CPropertyView)
      MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
      CHAIN_MSG_MAP( CDialogResize<CPropertyView> )
      REFLECT_NOTIFICATIONS()
   END_MSG_MAP()

   BEGIN_DLGRESIZE_MAP(CPropertyView)
      DLGRESIZE_CONTROL(IDC_COMBO, DLSZ_SIZE_X)
      DLGRESIZE_CONTROL(IDC_LIST, DLSZ_SIZE_X | DLSZ_SIZE_Y)
      DLGRESIZE_CONTROL(IDC_FRAME, DLSZ_SIZE_X | DLSZ_MOVE_Y)
      DLGRESIZE_CONTROL(IDC_TITLE, DLSZ_MOVE_Y)
      DLGRESIZE_CONTROL(IDC_DESCRIPTION, DLSZ_SIZE_X | DLSZ_MOVE_Y)
   END_DLGRESIZE_MAP()

   LRESULT OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      RECT rcClient;
      GetClientRect(&rcClient);

      CComboBox ctrlCombo = GetDlgItem(IDC_COMBO);
      ctrlCombo.AddString(_T("CAboutDlg"));
      ctrlCombo.SetCurSel(0);

      m_ctrlToolbar.SubclassWindow( CFrameWindowImplBase<>::CreateSimpleToolBarCtrl(m_hWnd, IDR_PROPERTYVIEW, FALSE, ATL_SIMPLE_TOOLBAR_STYLE | CCS_NODIVIDER | CCS_NOPARENTALIGN | TBSTYLE_FLAT) );
      m_ctrlToolbar.MoveWindow(0, 0, rcClient.right - rcClient.left, 10);

      static CFont font;
      CLogFont lf = GetFont();
      lf.SetBold();
      font.CreateFontIndirect(&lf);
      CStatic ctrlTitle = GetDlgItem(IDC_TITLE);
      ctrlTitle.SetFont(font);

      m_ctrlList.SubclassWindow(GetDlgItem(IDC_LIST));
      m_ctrlList.SetExtendedListStyle(PLS_EX_CATEGORIZED | PLS_EX_XPLOOK);
      m_ctrlList.AddItem( PropCreateCategory(_T("Appearance")) );
      m_ctrlList.AddItem( PropCreateSimple(_T("Name"), _T("CAboutDlg")) );
      m_ctrlList.AddItem( PropCreateSimple(_T("X"), 123L) );
      m_ctrlList.AddItem( PropCreateSimple(_T("Y"), 456L) );
      m_ctrlList.AddItem( PropCreateCategory(_T("Behaviour")) );
      m_ctrlList.AddItem( PropCreateSimple(_T("Enabled"), false) );
      m_ctrlList.AddItem( PropCreateFileName(_T("Icon"), _T("C:\\Temp\\Test.ico")) );

      DlgResize_Init(false, true, WS_CLIPCHILDREN);
      return TRUE;
   }
};


#endif // !defined(AFX_PROPERTYVIEW_H__20020427_21FD_35B8_BD11_0080AD509054__INCLUDED_)

