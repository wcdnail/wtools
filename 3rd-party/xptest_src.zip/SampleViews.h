#if !defined(AFX_SAMPLEVIEWS_H__20020430_6252_4F72_CFAF_0080AD509054__INCLUDED_)
#define AFX_SAMPLEVIEWS_H__20020430_6252_4F72_CFAF_0080AD509054__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CEditView : public CWindowImpl<CEditView, CEdit>
{
public:
   DECLARE_WND_SUPERCLASS(NULL, CEdit::GetWndClassName())

   BEGIN_MSG_MAP(CEditView)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
   END_MSG_MAP()
   
   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      LRESULT lRes = DefWindowProc();
      SetFont(AtlGetDefaultGuiFont());
      return lRes;
   }
};


class CColorView : public CWindowImpl<CColorView>
{
public:
   DECLARE_WND_CLASS(_T("ColorView"))

   BEGIN_MSG_MAP(CColorView)
      MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
   END_MSG_MAP()
   
   LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      CDCHandle dc( (HDC) wParam );
      CClientRect rc(m_hWnd);
      dc.FillSolidRect(&rc, RGB(180,0,0));
      return TRUE; // We're done
   }
};


#endif // !defined(AFX_SAMPLEVIEWS_H__20020430_6252_4F72_CFAF_0080AD509054__INCLUDED_)

