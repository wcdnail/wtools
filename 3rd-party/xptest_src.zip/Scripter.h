#if !defined(AFX_SCRIPTER_H__20020430_8702_9EA6_BA47_0080AD509054__INCLUDED_)
#define AFX_SCRIPTER_H__20020430_8702_9EA6_BA47_0080AD509054__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "atlscript.h"
#include "atldispa.h"

// The PROGID for MS JScript (JavaScript)
// Use L"VBScript" if you are more comfortable with VBScript.
#define SCRIPT_PROGID L"JScript"

extern const IID IID_IScripter;
extern const CLSID CLSID_Scripter;


class ATL_NO_VTABLE CScripter : 
   public CComObjectRootEx<CComSingleThreadModel>,
   public CComCoClass<CScripter, &CLSID_Scripter>,
   public IActiveScriptSiteImpl<CScripter>,
   public IActiveScriptSiteWindowImpl<CScripter>,
   public IDispatchImpl< IDispatch, NULL, NULL, 1, 0, CComDynTypeInfoHolder<CScripter> >
{
public:
   HWND m_hWnd;

   BEGIN_COM_MAP(CScripter)
      COM_INTERFACE_ENTRY(IActiveScriptSite)
      COM_INTERFACE_ENTRY(IActiveScriptSiteWindow)
      COM_INTERFACE_ENTRY(IDispatch)
   END_COM_MAP()

   DECLARE_PROTECT_FINAL_CONSTRUCT()

   // IDispatch map and methods

   BEGIN_DISPATCH_MAP(CScripter)
      DISP_METHOD1(insertText, VT_I4, VT_BSTR)
      DISP_METHOD0(scrollDown, VT_EMPTY)
   END_DISPATCH_MAP()

   long __stdcall insertText(BSTR bstr)
   {
      if( bstr == NULL ) return 0;
      USES_CONVERSION;
      LPCTSTR pstr = OLE2CT(bstr);
      CEdit ctrl = m_hWnd;
      ctrl.ReplaceSel(pstr);
      return 0;
   }

   VOID __stdcall scrollDown()
   {
      CEdit ctrl = m_hWnd;
      int nStart, nStop;
      ctrl.GetSel(nStart, nStop);
      int line = ctrl.LineFromChar(nStart);
      int nNewPos = ctrl.LineIndex(line+1);
      ctrl.SetSel(nNewPos, nNewPos);
      return;
   }

   // IActiveScriptSite

   STDMETHOD(GetItemInfo)(LPCOLESTR pstrName,
                          DWORD dwReturnMask,
                          IUnknown** ppiunkItem,
                          ITypeInfo** ppti)
   {
      ATLASSERT(pstrName);
      if( (dwReturnMask & SCRIPTINFO_ITYPEINFO)!=0 ) {
         *ppti = NULL;
         return E_FAIL;
      }
      if( (dwReturnMask & SCRIPTINFO_IUNKNOWN)==0 ) return E_FAIL;
      if( ppiunkItem==NULL ) return E_POINTER;
      *ppiunkItem = NULL;
      if( wcscmp( pstrName, L"MyObject" )==0 ) {
         return QueryInterface( IID_IUnknown, (LPVOID*)ppiunkItem );
      }
      return E_FAIL;
   }

   STDMETHOD(GetDocVersionString)(BSTR* pbstrVersion)
   {
      if( pbstrVersion == NULL ) return E_POINTER;
      CComBSTR bstr;
      bstr.LoadString(IDR_MAINFRAME);
      *pbstrVersion = bstr.Detach();
      return S_OK;
   }

   STDMETHOD(OnScriptError)(IActiveScriptError* pScriptError)
   {
      ATLASSERT(pScriptError);
      EXCEPINFO e;
      DWORD dwContext;
      ULONG ulLine;
      LONG lPos;
      pScriptError->GetExceptionInfo(&e);
      pScriptError->GetSourcePosition(&dwContext, &ulLine, &lPos);
      LPCTSTR pstrFormat = _T("An error occured while parsing the script:\nSource: %ws\nError: %08X\nDescription: %ws\nLine: %d\n");
      LPTSTR pstrStr = new TCHAR[1024];
      ::wsprintf( pstrStr, pstrFormat,
         e.bstrSource,
         e.scode,
         e.bstrDescription,
         ulLine+1);
      ::MessageBox(m_hWnd, pstrStr, _T("Compile Error"), MB_ICONERROR | MB_SYSTEMMODAL);
      delete [] pstrStr;
      //
      if( m_spIActiveScript ) m_spIActiveScript->SetScriptState(SCRIPTSTATE_DISCONNECTED);
      m_bNoFailures = false;
      return S_OK;
   }

   // Operations

   bool Run(HWND hWnd, LPCTSTR pstrFilename)
   {
      ATLASSERT(!::IsBadStringPtr(pstrFilename,-1));
      ATLASSERT(::IsWindow(hWnd));
      m_hWnd = hWnd;

      // Load the file (into stack buffer)
      CFile f;
      if( !f.Open(pstrFilename) ) {
         ::MessageBox(m_hWnd, _T("Unable to open script file..."), _T("File Error"), MB_ICONERROR);
         return false;
      }
      DWORD dwSize = f.GetSize();
      LPSTR pstr = (LPSTR) _alloca(dwSize + 1);
      f.Read(pstr, dwSize);
      f.Close();
      pstr[dwSize] = '\0';

      CComBSTR bstr = pstr;

      // Create the Active Scripting Engine.
      CComPtr<IActiveScript> spScript;
      HRESULT Hr;
      Hr = spScript.CoCreateInstance(SCRIPT_PROGID);
      if( FAILED(Hr) ) {
         // No JavaScript?
         ::MessageBox(m_hWnd, _T("Error: Could not create Script component?"), _T(""), MB_ICONERROR);
         return false; 
      }

      CComQIPtr<IActiveScriptSite> spPass(GetUnknown());
      if( spPass == NULL ) return false;

      Hr = spScript->SetScriptSite(spPass);
      if( FAILED(Hr) ) return false;

      CComQIPtr<IActiveScriptParse> spParse(spScript);
      if( spParse == NULL ) return false;

      spParse->InitNew();

      // Add the custom methods...
      // They are initialized in the GetItemInfo() method (see above).
      DWORD dwFlags = SCRIPTITEM_ISVISIBLE | SCRIPTITEM_GLOBALMEMBERS;
      Hr = spScript->AddNamedItem(OLESTR("MyObject"), dwFlags );
      if( FAILED(Hr) ) return false;

      // Start the scripting engine...
      m_spIActiveScript = spScript;
      Hr = spScript->SetScriptState(SCRIPTSTATE_STARTED);
      if( FAILED(Hr) ) return false;

      // Run the script...
      Hr = spParse->ParseScriptText(bstr,
                                    NULL,
                                    NULL,
                                    NULL,
                                    0,
                                    0,
                                    0,
                                    NULL,
                                    NULL);

      spScript->SetScriptState(SCRIPTSTATE_CLOSED);

      return true;
   }
};


#endif // !defined(AFX_SCRIPTER_H__20020430_8702_9EA6_BA47_0080AD509054__INCLUDED_)
