#if !defined(AFX_SOLUTIONEXPLORERVIEW_H__20020424_B184_A9DC_E870_0080AD509054__INCLUDED_)
#define AFX_SOLUTIONEXPLORERVIEW_H__20020424_B184_A9DC_E870_0080AD509054__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CFileView : public CWindowImpl<CFileView>
{
public:
   DECLARE_WND_CLASS_EX(_T("WTL_FileView"), 0, COLOR_3DFACE)
   
   CToolBarXPCtrl m_ctrlToolbar;
   CTreeViewCtrl m_ctrlTree;
   CImageListCtrl m_Images;

   BEGIN_MSG_MAP(CFileView)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
      MESSAGE_HANDLER(WM_SIZE, OnSize)
      NOTIFY_CODE_HANDLER(TVN_SELCHANGED, OnSelChanged)
      // Not entirely sure why this filter is needed...
      if( uMsg==WM_NOTIFY && ((LPNMHDR)lParam)->hwndFrom==m_ctrlToolbar ) 
         REFLECT_NOTIFICATIONS()
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      m_ctrlToolbar.SubclassWindow( CFrameWindowImplBase<>::CreateSimpleToolBarCtrl(m_hWnd, IDR_SOLUTIONEXPLORER, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE) );

      m_Images.Create(IDB_FOLDERS, 16, 1, RGB(255,0,255));
      DWORD dwStyle = WS_BORDER | WS_CHILD | WS_VISIBLE | TVS_HASBUTTONS | TVS_HASLINES;
      m_ctrlTree.Create(m_hWnd, rcDefault, NULL, dwStyle);
      m_ctrlTree.SetImageList(m_Images, TVSIL_NORMAL);

      HTREEITEM hRoot, hItem;
      hRoot = m_ctrlTree.InsertItem(_T("TestProject"), 0, 0, TVI_ROOT, TVI_LAST);
      hItem = m_ctrlTree.InsertItem(_T("Source Files"), 0, 0, hRoot, TVI_LAST);
      m_ctrlTree.InsertItem(_T("Test.cpp"), 1, 1, hItem, TVI_LAST);
      m_ctrlTree.Expand(hItem);
      hItem = m_ctrlTree.InsertItem(_T("Header Files"), 0, 0, hRoot, TVI_LAST);
      m_ctrlTree.InsertItem(_T("Test.h"), 2, 2, hItem, TVI_LAST);
      m_ctrlTree.Expand(hItem);
      m_ctrlTree.Expand(hRoot);
      return 0;
   }
   LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      return TRUE; // Children fills entire client area
   }
   LRESULT OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      if( !m_ctrlToolbar.IsWindow() || !m_ctrlTree.IsWindow() ) return 0;
      RECT rc;
      GetClientRect(&rc);
      RECT rcTb = { rc.left, rc.top, rc.right, rc.top + 24 };
      m_ctrlToolbar.MoveWindow(&rcTb);
      m_ctrlToolbar.GetWindowRect(&rcTb);
      RECT rcTree = { rc.left, rcTb.bottom-rcTb.top, rc.right, rc.bottom };
      m_ctrlTree.MoveWindow(&rcTree);
      return 0;
   }
   LRESULT OnSelChanged(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)
   {
      // Add code here
      return 0;
   }
};


class CClassView : public CWindowImpl<CClassView>
{
public:
   DECLARE_WND_CLASS_EX(_T("WTL_ClassView"), 0, COLOR_3DFACE)
   
   CToolBarXPCtrl m_ctrlToolbar;
   CTreeViewCtrl m_ctrlTree;
   CImageListCtrl m_Images;

   BEGIN_MSG_MAP(CClassView)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
      MESSAGE_HANDLER(WM_SIZE, OnSize)
      // Not entirely sure why this filter is needed...
      if( uMsg==WM_NOTIFY && ((LPNMHDR)lParam)->hwndFrom==m_ctrlToolbar ) 
         REFLECT_NOTIFICATIONS()
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      m_ctrlToolbar.SubclassWindow( CFrameWindowImplBase<>::CreateSimpleToolBarCtrl(m_hWnd, IDR_CLASSVIEW, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE) );

      m_Images.Create(IDB_FOLDERS, 16, 1, RGB(255,0,255));
      DWORD dwStyle = WS_BORDER | WS_CHILD | WS_VISIBLE | TVS_HASBUTTONS | TVS_HASLINES;
      m_ctrlTree.Create(m_hWnd, rcDefault, NULL, dwStyle);
      m_ctrlTree.SetImageList(m_Images, TVSIL_NORMAL);

      HTREEITEM hRoot, hItem;
      hRoot = m_ctrlTree.InsertItem(_T("TestProject"), 0, 0, TVI_ROOT, TVI_LAST);
      hItem = m_ctrlTree.InsertItem(_T("CAboutDlg"), 2, 2, hRoot, TVI_LAST);
      hItem = m_ctrlTree.InsertItem(_T("CMainFrame"), 2, 2, hRoot, TVI_LAST);
      m_ctrlTree.Expand(hRoot);
      return 0;
   }
   LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      return TRUE; // Children fills entire client area
   }
   LRESULT OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      if( !m_ctrlToolbar.IsWindow() || !m_ctrlTree.IsWindow() ) return 0;
      RECT rc;
      GetClientRect(&rc);
      RECT rcTb = { rc.left, rc.top, rc.right, rc.top + 24 };
      m_ctrlToolbar.MoveWindow(&rcTb);
      m_ctrlToolbar.GetWindowRect(&rcTb);
      RECT rcTree = { rc.left, rcTb.bottom-rcTb.top, rc.right, rc.bottom };
      m_ctrlTree.MoveWindow(&rcTree);
      return 0;
   }
};


class CSolutionExplorerView : public CWindowImpl<CSolutionExplorerView>
{
public:
   DECLARE_WND_CLASS_EX(_T("WTL_SolutionExplorerView"), 0, COLOR_3DFACE)

   CDlgContainerCtrl m_ctrlViews;
   CImageListCtrl m_Images;
   CDotNetTabCtrl m_ctrlTab;
   CFileView m_viewFile;
   CClassView m_viewClass;
   CFileView m_viewResource; // Same as FileView. Too lazy to create more views...

   BOOL PreTranslateMessage(MSG* /*pMsg*/)
   {
      return FALSE;
   }

   BEGIN_MSG_MAP(CSolutionExplorerView)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_ERASEBKGND, OnEraseBkgnd)
      MESSAGE_HANDLER(WM_SIZE, OnSize)
      NOTIFY_CODE_HANDLER(TCN_SELCHANGE, OnSelChange)
      REFLECT_NOTIFICATIONS()
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      m_ctrlViews.Create(m_hWnd, rcDefault);
      m_viewFile.Create(m_ctrlViews, rcDefault);
      m_viewClass.Create(m_ctrlViews, rcDefault);
      m_viewResource.Create(m_ctrlViews, rcDefault);
      m_ctrlViews.AddItem( m_viewFile );
      m_ctrlViews.AddItem( m_viewClass );
      m_ctrlViews.AddItem( m_viewResource );

      m_Images.Create(IDB_FOLDERVIEW, 16, 1, RGB(255,0,255));
      m_ctrlTab.Create(m_hWnd, rcDefault, NULL, WS_VISIBLE | WS_CHILD | WS_CLIPCHILDREN | WS_CLIPSIBLINGS | TCS_BOTTOM | TCS_TOOLTIPS);
      m_ctrlTab.SetExtendedStyle(0, TCS_EX_FLATSEPARATORS | TCS_EX_COMPRESSLINE);
      m_ctrlTab.SetImageList(m_Images);
      TCITEM tci = { 0 };
      tci.mask = TCIF_TEXT | TCIF_IMAGE;
      tci.pszText = _T("Solution Explorer");
      tci.iImage = 0;
      m_ctrlTab.InsertItem(0, &tci);
      tci.pszText = _T("Class View");
      tci.iImage = 1;
      m_ctrlTab.InsertItem(1, &tci);
      tci.pszText = _T("Resource View");
      tci.iImage = 2;
      m_ctrlTab.InsertItem(2, &tci);
      m_ctrlTab.SetCurSel(0);
      
      return 0;
   }
   LRESULT OnEraseBkgnd(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      return TRUE; // Children fills entire client area
   }
   LRESULT OnSize(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      if( !m_ctrlViews.IsWindow() || !m_ctrlTab.IsWindow() ) return 0;
      RECT rc;
      GetClientRect(&rc);
      RECT rcPager = { rc.left, rc.top, rc.right, rc.bottom - 24 };
      m_ctrlViews.MoveWindow(&rcPager);
      RECT rcTab = { rc.left, rc.bottom - 24, rc.right, rc.bottom };
      m_ctrlTab.MoveWindow(&rcTab);
      return 0;
   }
   LRESULT OnSelChange(int /*idCtrl*/, LPNMHDR /*pnmh*/, BOOL& /*bHandled*/)
   {
      m_ctrlViews.SetCurSel( m_ctrlTab.GetCurSel() );
      return 0;
   }
};


#endif // !defined(AFX_SOLUTIONEXPLORERVIEW_H__20020424_B184_A9DC_E870_0080AD509054__INCLUDED_)

