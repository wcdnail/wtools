// MdiTest3View.h : interface of the CSourceView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MDITEST3VIEW_H__F2FF5C49_BD87_4CD2_9AF1_57DDECF2C5DA__INCLUDED_)
#define AFX_MDITEST3VIEW_H__F2FF5C49_BD87_4CD2_9AF1_57DDECF2C5DA__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CSourceView : 
   public CWindowImpl<CSourceView, CRichEditCtrl>,
   public CRichEditCommands<CSourceView>
{
public:
   DECLARE_WND_SUPERCLASS(NULL, CRichEditCtrl::GetWndClassName())

   CMDICommandBarXPCtrl* m_pCmdBar;

   typedef struct RtfStream
   {
      LPCSTR pstr;
      DWORD pos;
   };

   CSourceView() :
      m_pCmdBar(NULL)
   {
   }

   BOOL PreTranslateMessage(MSG* pMsg)
   {
      pMsg;
      return FALSE;
   }

   BEGIN_MSG_MAP(CSourceView)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_CONTEXTMENU, OnContextMenu)
      CHAIN_MSG_MAP_ALT(CRichEditCommands<CSourceView>, 1)
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      LRESULT lRes = DefWindowProc();
      HFONT hFont = (HFONT) ::GetStockObject(ANSI_VAR_FONT);
      SetFont(hFont);
      SetTargetDevice(NULL, 1);
      LimitText(30000);
      return lRes;
   }
   LRESULT OnContextMenu(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM lParam, BOOL& /*bHandled*/)
   {
      ATLASSERT(m_pCmdBar);
      CMenuHandle menu = m_pCmdBar->m_hMenu;
      CMenuHandle submenu = menu.GetSubMenu(1);
      POINT pt = {  GET_X_LPARAM(lParam),  GET_Y_LPARAM(lParam) };
      if( lParam == (DWORD) -1 ) {
         ::GetCaretPos(&pt);
         ::ClientToScreen(m_hWnd, &pt);
      }
      m_pCmdBar->TrackPopupMenu(submenu, TPM_LEFTALIGN | TPM_LEFTBUTTON, pt.x, pt.y);
      return 0;
   }

   // Operations

   void LoadText(LPCSTR pstrText)
   {
      // Syntax highlight text
      // NOTE: This is a one-time operation.
      //       No run-time syntax highlighting of modified
      //       text!!!
      CString sText = CJScriptFormat::Format(CString(pstrText));
      // Stream RTF into control
      CString sRtf;
      sRtf = "{\\rtf1\\ansi\\ansicpg1252\\deff0\\deflang1030{\\fonttbl{\\f0\\fswiss\\fcharset0 Arial;}}{\\colortbl ;\\red0\\green0\\blue255;\\red0\\green0\\blue140;\\red0\\green140\\blue0;\\red130\\green130\\blue130;}\\viewkind4\\uc1\\pard\\f0\\fs20 ";
      sRtf += sText;
      sRtf += "\\par}";
      USES_CONVERSION;
      RtfStream st = { T2CA(sRtf), 0 };
      EDITSTREAM es = { 0 };
      es.dwCookie = (DWORD) &st;
      es.dwError = 0;
      es.pfnCallback = _StreamReadCallback;
      ATLTRY( StreamIn(SF_RTF, es) );
   }

   // Implementation

   static DWORD CALLBACK _StreamReadCallback(DWORD dwCookie, LPBYTE pbBuff, LONG cb, LONG FAR *pcb)
   {
      RtfStream* pS = reinterpret_cast<RtfStream*>(dwCookie);
      ATLASSERT(pS);
      LPCSTR pstr = pS->pstr + pS->pos;
      ATLASSERT(!::IsBadStringPtrA(pstr, -1));
      LONG len = ::lstrlenA(pstr);
      if( cb>len ) cb = len;
      ::CopyMemory(pbBuff, pstr, cb);
      pS->pos += cb;
      *pcb = cb;
      return 0;
   }
};


#endif // !defined(AFX_MDITEST3VIEW_H__F2FF5C49_BD87_4CD2_9AF1_57DDECF2C5DA__INCLUDED_)
