// XpTest.cpp : main source file for MdiTest3.exe
//

#include "stdafx.h"

#include <atlframe.h>
#include <atlmisc.h>
#include <atlctrls.h>
#include <atldlgs.h>
#include <atlctrlw.h>
#include <atlctrlx.h>

#include "resource.h"

#include "atlgdix.h"
#include "atlwinmisc.h"
#include "atlctrlsext.h"
#include "atlwfile.h"

#include "atldib.h"
#include "MenuShadows.h"

#include "atlctrlxp.h"
#include "atlctrlxp2.h"

#include "atldock.h"
#include "atldock2.h"

#include "AutoHideXP.h"

#include "PropertyList.h"
#include "CoolTabCtrls.h"
#include "DlgTabCtrl.h"
#include "MDIContainer.h"

#include "JScriptFormat.h"

#include "SolutionExplorerView.h"
#include "PropertyView.h"
#include "SourceView.h"
#include "SampleViews.h"
#include "Scripter.h"
#include "OptionsDlg.h"
#include "KeyboardDlg.h"
#include "AboutDlg.h"

#include "ChildFrm.h"
#include "MainFrm.h"


CAppModule _Module;

// GUIDs for scripting code
// Please create new GUIDs if you reuse the code...
const IID IID_IScripter = {0x175C8D33,0x01C4,0x4B7B,{0x87,0x66,0x7E,0x71,0x30,0x07,0x77,0xB3}};
const CLSID CLSID_Scripter = {0xDF58AA46,0xC53A,0x4E21,{0x85,0xE7,0xAC,0x7C,0xC6,0xB5,0xFF,0xA0}};


int Run(LPTSTR /*lpstrCmdLine*/ = NULL, int nCmdShow = SW_SHOWDEFAULT)
{
   CMessageLoop theLoop;
   _Module.AddMessageLoop(&theLoop);

   CMainFrame wndMain;
   if( wndMain.CreateEx() == NULL ) {
      ATLTRACE(_T("Main window creation failed!\n"));
      return 0;
   }
   wndMain.ShowWindow(nCmdShow);

   int nRet = theLoop.Run();

   _Module.RemoveMessageLoop();
   return nRet;
}

int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)
{
   HRESULT hRes = ::CoInitialize(NULL);
   ATLASSERT(SUCCEEDED(hRes));

   // this resolves ATL window thunking problem when Microsoft Layer for Unicode (MSLU) is used
   ::DefWindowProc(NULL, 0, 0, 0L);

   AtlInitCommonControls(ICC_COOL_CLASSES | 
                         ICC_WIN95_CLASSES |
                         ICC_HOTKEY_CLASS);   // add flags to support other controls

   HMODULE hInstRich = ::LoadLibrary(CRichEditCtrl::GetLibraryName());
   ATLASSERT(hInstRich != NULL);

   hRes = _Module.Init(NULL, hInstance);
   ATLASSERT(SUCCEEDED(hRes));

   AtlAxWinInit();

   int nRet = Run(lpstrCmdLine, nCmdShow);

   ::FreeLibrary(hInstRich);

   _Module.Term();
   ::CoUninitialize();

   return nRet;
}
