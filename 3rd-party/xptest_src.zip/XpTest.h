// MdiTest3.h
