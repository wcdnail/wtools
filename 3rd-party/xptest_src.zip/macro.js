// This is a sample macro
// It is written in JavaScript and integrates into the application
// by extending JScript with a few global functions...
// Pick the 'Run Macro' menu item to see it in action!

// First we insert some text
var s = "Testing macro text insert...\n";
insertText(s);

// The second test scrolls 3 lines down
var i;
for( i=0; i<3; i++ ) {
	scrollDown();
}

// Finally we just fool around
for( i=0; i<12; i++ ) {
	insertText( "Test " + i + "...\n");
}