// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__8D2936ED_9E84_4EEE_92DA_4DDE7CC73914__INCLUDED_)
#define AFX_MAINFRM_H__8D2936ED_9E84_4EEE_92DA_4DDE7CC73914__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CMainFrame : 
   public CMDIFrameWindowImpl<CMainFrame>, 
   public CMDICommands<CMainFrame>,
   public CCustomizableToolBarCommands<CMainFrame>,
   public CUpdateUI<CMainFrame>,
   public CMessageFilter, 
   public CIdleHandler
{
public:
   DECLARE_FRAME_WND_CLASS(NULL, IDR_MAINFRAME)

   CMDICommandBarXPCtrl m_CmdBar;
   CMultiPaneStatusBarXPCtrl m_StatusBar;
   CMDIContainer m_MDIContainer;
   CAutoHideXP m_AutoHide;
   CImageListCtrl m_Images;
   CDotNetDockingWindow m_dock;
   CComboBoxXPCtrl m_Combo;
   CAccelerator m_accel;

   CSolutionExplorerView m_SolutionView;
   CPropertyView m_PropertyView;
   CEditView m_EditView;
   CColorView m_ColorView;

   virtual BOOL PreTranslateMessage(MSG* pMsg)
   {
      if( CMDIFrameWindowImpl<CMainFrame>::PreTranslateMessage(pMsg) )
         return TRUE;

      if( !m_accel.IsNull() && m_accel.TranslateAccelerator(m_hWnd, pMsg) ) 
         return TRUE;

      HWND hWnd = MDIGetActive();
      if( hWnd != NULL )
         return (BOOL)::SendMessage(hWnd, WM_FORWARDMSG, 0, (LPARAM) pMsg);

      return FALSE;
   }
   virtual BOOL OnIdle()
   {
      HWND hWnd = MDIGetActive();
      UISetCheck(ID_VIEW_VIEW1, m_SolutionView.IsWindow() && m_SolutionView.IsWindowVisible());
      UISetCheck(ID_VIEW_VIEW2, m_PropertyView.IsWindow() && m_PropertyView.IsWindowVisible());
      UIEnable(ID_EDIT_COPY, hWnd!=NULL);
      UIEnable(ID_EDIT_CUT, hWnd!=NULL);
      UIEnable(ID_EDIT_PASTE, hWnd!=NULL);
      UIEnable(ID_TOOLS_RUNMACRO, hWnd!=NULL);
      UIUpdateToolBar();
      m_dock.OnIdle();
      return FALSE;
   }

#ifndef BTNS_SHOWTEXT
#define BTNS_SHOWTEXT           0x0040
#endif  // BTNS_SHOWTEXT

   void AddButtonText(CToolBarCtrl tb, UINT nID, UINT nRes)
   {
      TBBUTTONINFO tbi = { 0 };
      tbi.cbSize = sizeof(TBBUTTONINFO),
      tbi.dwMask  = TBIF_STYLE;
      tb.GetButtonInfo(nID, &tbi);
      tbi.dwMask = TBIF_STYLE | TBIF_TEXT;
      tbi.fsStyle |= TBSTYLE_AUTOSIZE | BTNS_SHOWTEXT;
      CString s(MAKEINTRESOURCE(nRes));
      tbi.pszText = (LPTSTR) (LPCTSTR) s;
      tb.SetButtonInfo(nID, &tbi);
   }
   void AddDropDownButton(CToolBarCtrl tb, UINT nID)
   {
      tb.SetExtendedStyle(TBSTYLE_EX_DRAWDDARROWS); 

      TBBUTTONINFO tbi = { 0 };
      tbi.cbSize  = sizeof(TBBUTTONINFO);
      tbi.dwMask  = TBIF_STYLE;
      tb.GetButtonInfo(nID, &tbi);
      tbi.fsStyle |= TBSTYLE_DROPDOWN;
      //tbi.fsStyle |= BTNS_WHOLEDROPDOWN ;      
      tb.SetButtonInfo(nID, &tbi);
   }
   void AddControlToToolbar(CToolBarCtrl tb, HWND hWnd, USHORT cx, UINT nCmdPos, bool bIsCommandId, bool bInsertBefore = true)
   {
      ATLASSERT(::IsWindow(hWnd));
      static UINT s_nCmd = 45000; // Unique number for new toolbar separator
      int iIndex = nCmdPos;
      if( bIsCommandId ) iIndex = tb.CommandToIndex(nCmdPos);
      if( !bInsertBefore ) iIndex++;
      
      // Create a separator toolbar button
      TBBUTTON but = { 0 };
      but.fsStyle = TBSTYLE_SEP;
      but.fsState = TBSTATE_ENABLED;
      but.idCommand = s_nCmd;
      BOOL bRes = tb.InsertButton(iIndex, &but);
      ATLASSERT(bRes);
      bRes;
      TBBUTTONINFO info;
      info.cbSize = sizeof(info);
      info.dwMask = TBIF_SIZE;
      info.cx = cx;
      tb.SetButtonInfo(s_nCmd++, &info);

      // Chain the control to its new parent
      ::SetParent(hWnd, tb);
      // Position the new control on top of the separator
      RECT rc;
      tb.GetItemRect(iIndex, &rc);
      ::SetWindowPos(hWnd, NULL, rc.left, rc.top, rc.right-rc.left, rc.bottom-rc.top, SWP_NOACTIVATE);
   }

   BEGIN_UPDATE_UI_MAP(CMainFrame)
      UPDATE_ELEMENT(ID_FILE_PRINT, UPDUI_MENUPOPUP | UPDUI_TOOLBAR)
      UPDATE_ELEMENT(ID_FILE_SAVE, UPDUI_MENUPOPUP | UPDUI_TOOLBAR)
      UPDATE_ELEMENT(ID_EDIT_COPY, UPDUI_MENUPOPUP | UPDUI_TOOLBAR)
      UPDATE_ELEMENT(ID_EDIT_CUT, UPDUI_MENUPOPUP | UPDUI_TOOLBAR)
      UPDATE_ELEMENT(ID_EDIT_PASTE, UPDUI_MENUPOPUP | UPDUI_TOOLBAR)
      UPDATE_ELEMENT(ID_TOOLS_RUNMACRO, UPDUI_MENUPOPUP | UPDUI_TOOLBAR)
      UPDATE_ELEMENT(ID_VIEW_VIEW1, UPDUI_MENUPOPUP)
      UPDATE_ELEMENT(ID_VIEW_VIEW2, UPDUI_MENUPOPUP)
      UPDATE_ELEMENT(ID_VIEW_TOOLBAR, UPDUI_MENUPOPUP)
      UPDATE_ELEMENT(ID_VIEW_STATUS_BAR, UPDUI_MENUPOPUP)
   END_UPDATE_UI_MAP()

   BEGIN_MSG_MAP(CMainFrame)
      MESSAGE_HANDLER(WM_CREATE, OnCreate)
      MESSAGE_HANDLER(WM_CLOSE, OnClose)
      COMMAND_ID_HANDLER(ID_APP_EXIT, OnFileExit)
      COMMAND_ID_HANDLER(ID_FILE_NEW, OnFileNew)
      COMMAND_ID_HANDLER(ID_FILE_OPEN, OnFileOpen)
      COMMAND_ID_HANDLER(ID_FILE_CLOSE, OnFileClose)
      COMMAND_ID_HANDLER(ID_TOOLS_RUNMACRO, OnToolRunMacro)
      COMMAND_ID_HANDLER(ID_TOOLS_OPTIONS, OnToolOptions)
      COMMAND_ID_HANDLER(ID_TOOLS_CUSTOMIZE, OnToolCustomize)
      COMMAND_ID_HANDLER(ID_VIEW_TOOLBAR, OnViewToolBar)
      COMMAND_ID_HANDLER(ID_VIEW_STATUS_BAR, OnViewStatusBar)
      COMMAND_ID_HANDLER(ID_APP_KEYBOARD, OnAppKeyboard)
      COMMAND_ID_HANDLER(ID_APP_ABOUT, OnAppAbout)
      NOTIFY_CODE_HANDLER(TBN_DROPDOWN, OnToolbarDropDown)
      CHAIN_MDI_CHILD_COMMANDS()
      CHAIN_MSG_MAP(CMDICommands<CMainFrame>)
      CHAIN_MSG_MAP(CCustomizableToolBarCommands<CMainFrame>)
      CHAIN_MSG_MAP(CUpdateUI<CMainFrame>)
      CHAIN_MSG_MAP(CMDIFrameWindowImpl<CMainFrame>)
      // This is actually for the XP combobox
      if( uMsg == WM_COMMAND && LOWORD(wParam) == IDC_COMBO ) REFLECT_NOTIFICATIONS()
   END_MSG_MAP()

   LRESULT OnCreate(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
   {
      // Create command bar window
      HWND hWndCmdBar = m_CmdBar.Create(m_hWnd, rcDefault, NULL, ATL_SIMPLE_CMDBAR_PANE_STYLE);
      // Attach menu
      m_CmdBar.AttachMenu(GetMenu());
      // Load command bar images
      m_CmdBar.LoadImages(IDR_MAINFRAME);
      // Remove old menu
      SetMenu(NULL);

      HWND hWndToolBar = CreateSimpleToolBarCtrl(m_hWnd, IDR_MAINFRAME, FALSE, ATL_SIMPLE_TOOLBAR_PANE_STYLE | TBSTYLE_LIST | CCS_ADJUSTABLE);
      InitToolBar(hWndToolBar, IDR_MAINFRAME);
      CToolBarCtrl tb = hWndToolBar;
      // Load previously saved button layout
      tb.RestoreState(HKEY_CURRENT_USER, _T("SOFTWARE\\BjarkeViksoe\\XpUi Sample"), _T("Toolbar"));
      // Manipulate some toolbar buttons
      // Notice how the TBSTYLE_LIST style was added to place text on the
      // right of the buttons...
      AddDropDownButton(tb, ID_FILE_OPEN);
      AddButtonText(tb, ID_FILE_OPEN, IDS_OPEN);
      AddButtonText(tb, ID_TOOLS_RUNMACRO, IDS_RUNMACRO);
      tb.AutoSize();

      // Create rebar
      CreateSimpleReBar(ATL_SIMPLE_REBAR_NOBORDER_STYLE);
      AddSimpleReBarBand(hWndCmdBar);
      AddSimpleReBarBand(hWndToolBar, NULL, TRUE);

      // Create StatusBar
      m_hWndStatusBar = m_StatusBar.Create(m_hWnd);
      int aPanes[] = { ID_DEFAULT_PANE, IDS_SB_PANE1, IDS_SB_PANE2 };
      m_StatusBar.SetPanes(aPanes, 3);

      // Create XP ComboBox in ToolBar
      RECT rcCombo = { 320, 0, 440, 100 }; // Hardcode position for now...
      DWORD dwStyle = WS_CHILD | WS_VISIBLE | CBS_DROPDOWN;
      m_Combo.Create(m_hWnd, rcCombo, _T("Test..."), dwStyle, 0, IDC_COMBO);
      m_Combo.SetFont(AtlGetDefaultGuiFont());
      m_Combo.SetParent(hWndToolBar);
      m_Combo.AddString(_T("String #1"));
      m_Combo.AddString(_T("String #2"));
      m_Combo.AddString(_T("String #3"));

      // Create MDI Client
      CreateMDIClient();
      m_CmdBar.SetMDIClient(m_hWndMDIClient);
     
      // Docking Windows
      m_dock.Create(m_hWnd, rcDefault);
      m_dock.SetExtendedDockStyle(DCK_EX_DESTROYONCLOSE);

      // Attach MDI Container (manages the MDI Client and tabbed frame)
      m_MDIContainer.Create(m_dock, rcDefault, NULL, WS_CHILD | WS_VISIBLE | WS_CLIPCHILDREN | WS_CLIPSIBLINGS);
      m_MDIContainer.SetMDIClient(m_hWndMDIClient);

      // Create docked views
      m_dock.SetClient(m_MDIContainer);
      m_SolutionView.Create(m_dock, rcDefault, NULL, ATL_SIMPLE_DOCKVIEW_STYLE);
      m_SolutionView.SetWindowText(_T("Solution Explorer"));
      m_PropertyView.Create(m_dock);
      m_PropertyView.SetWindowText(_T("Property View"));
      m_dock.AddWindow(m_SolutionView);
      m_dock.AddWindow(m_PropertyView, DCK_NOTOP | DCK_NOBOTTOM);

      m_dock.DockWindow(m_SolutionView, DOCK_RIGHT);
      RECT rcFloat = { 300, 300, 600, 640 };
      m_dock.FloatWindow(m_PropertyView, rcFloat);

      m_dock.SetPaneSize(DOCK_LEFT, 200);
      m_dock.SetPaneSize(DOCK_RIGHT, 160);

      // The AutoHide control
      m_Images.Create(IDB_AUTOVIEWS, 16, 1, RGB(255,0,255));
      m_AutoHide.Create(m_hWnd, rcDefault);
      m_AutoHide.SetImageList(m_Images);
      m_AutoHide.SetClient(m_dock);

      m_EditView.Create(m_AutoHide, rcDefault, _T("Edit View"), ES_MULTILINE | ATL_SIMPLE_AUTOHIDEVIEW_STYLE);
      m_AutoHide.AddView(m_EditView, AUTOHIDE_LEFT, 0);
      m_EditView.SetWindowText(_T("Bla bla bla..."));
      m_ColorView.Create(m_AutoHide, rcDefault, _T("Color View"), ATL_SIMPLE_AUTOHIDEVIEW_STYLE);
      m_AutoHide.AddView(m_ColorView, AUTOHIDE_LEFT, 1);

      // Prepare XP menu- and toolbars
      m_hWndClient = m_AutoHide;
      m_CmdBar.AddToolbar(hWndToolBar);
      m_CmdBar.Prepare();

      UIAddToolBar(hWndToolBar);
      UIEnable(ID_FILE_PRINT, 0);
      UIEnable(ID_FILE_SAVE, 0);
      UISetCheck(ID_VIEW_VIEW1, 1);
      UISetCheck(ID_VIEW_VIEW2, 1);
      UISetCheck(ID_VIEW_TOOLBAR, 1);
      UISetCheck(ID_VIEW_STATUS_BAR, 1);

      // Register object for message filtering and idle updates
      CMessageLoop* pLoop = _Module.GetMessageLoop();
      ATLASSERT(pLoop != NULL);
      pLoop->AddMessageFilter(this);
      pLoop->AddIdleHandler(this);

      PostMessage(WM_COMMAND, MAKEWPARAM(ID_FILE_NEW, 0), 0);
      return 0;
   }
   LRESULT OnClose(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
   {
      // Get the toolbar HWND.
      // Ok, I could have stored it in a member variable,
      // but this is much more fun 8-(
      CReBarCtrl rebar = m_hWndToolBar;
      UINT iBandIndex = rebar.IdToIndex(ATL_IDW_BAND_FIRST + 1); // toolbar is 2nd added band
      REBARBANDINFO rbi = { 0 };
      rbi.cbSize = sizeof(REBARBANDINFO);
      rbi.fMask = RBBIM_CHILD;
      rebar.GetBandInfo(iBandIndex, &rbi);
      CToolBarCtrl tb = rbi.hwndChild;
      tb.SaveState(HKEY_CURRENT_USER, _T("SOFTWARE\\BjarkeViksoe\\XpUi Sample"), _T("Toolbar"));

      bHandled = FALSE;
      return 0;
   }

   LRESULT OnFileNew(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      CChildFrame* pChild = new CChildFrame;
      pChild->CreateEx(m_hWndMDIClient);
      pChild->m_view.m_pCmdBar = &m_CmdBar;
      return 0;
   }
   LRESULT OnFileOpen(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      LPCTSTR lpcstrFilter = 
         _T("JavaScript Files (*.js)\0*.js\0")
         _T("All Files (*.*)\0*.*\0")
         _T("");
      CModulePath sCurDir;
      CString sPath = sCurDir + _T("..\\");  // Assumes project is build in \Release or \Debug
      // Open file
      CFileDialog dlg(TRUE, _T("js"), _T(""), OFN_EXPLORER | OFN_HIDEREADONLY, lpcstrFilter);
      dlg.m_ofn.lpstrInitialDir = sPath;
      if( dlg.DoModal() == IDOK ) {
         // Open file and read text...
         CFile f;
         if( !f.Open(dlg.m_ofn.lpstrFile) ) return 0;
         DWORD dwSize = f.GetSize();
         LPSTR pstr = (LPSTR) _alloca(dwSize + 1);
         f.Read(pstr, dwSize);
         f.Close();
         pstr[dwSize] = '\0';
         // Create new child and populate it with text
         CChildFrame* pChild = new CChildFrame;
         pChild->CreateEx(m_hWndMDIClient, rcDefault, dlg.m_ofn.lpstrFileTitle);
         pChild->m_view.m_pCmdBar = &m_CmdBar;
         pChild->m_view.LoadText(pstr);
      }
      return 0;
   }
   LRESULT OnFileClose(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      HWND hWnd = MDIGetActive();
      if( hWnd ) ::PostMessage(hWnd, WM_CLOSE, 0, 0);
      return 0;
   }
   LRESULT OnFileExit(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      PostMessage(WM_CLOSE);
      return 0;
   }

   LRESULT OnToolRunMacro(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      // Get the active MDI child
      HWND hWndActive = MDIGetActive();
      if( hWndActive==NULL ) return 0;
      // Get the EDIT portion (RichEdit control) of the MDI child
      hWndActive = ::GetWindow(hWndActive, GW_CHILD);

      LPCTSTR lpcstrFilter = 
         _T("JavaScript Files (*.js)\0*.js\0")
         _T("All Files (*.*)\0*.*\0")
         _T("");
      CModulePath sCurDir;
      CString sPath = sCurDir + _T("..\\");   // HACK: Assumes project is build in \Release or \Debug
      // Open file
      CFileDialog dlg(TRUE, _T("js"), _T(""), OFN_EXPLORER | OFN_HIDEREADONLY, lpcstrFilter);
      dlg.m_ofn.lpstrInitialDir = sPath;
      if( dlg.DoModal() == IDOK ) {
         // Create script object and run macro...
         CComObject<CScripter>* pScript;
         HRESULT Hr = CComObject<CScripter>::CreateInstance(&pScript);
         if( FAILED(Hr) ) return 0;
         pScript->AddRef();
         pScript->Run(hWndActive, dlg.m_ofn.lpstrFile);
         pScript->Release();
      }
      return 0;
   }
   LRESULT OnToolOptions(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      COptionsDlg dlg;
      dlg.DoModal();
      return 0;
   }
   LRESULT OnToolCustomize(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      // Get the toolbar HWND.
      CReBarCtrl rebar = m_hWndToolBar;
      UINT iBandIndex = rebar.IdToIndex(ATL_IDW_BAND_FIRST + 1); // toolbar is 2nd added band
      REBARBANDINFO rbi = { 0 };
      rbi.cbSize = sizeof(REBARBANDINFO);
      rbi.fMask = RBBIM_CHILD;
      rebar.GetBandInfo(iBandIndex, &rbi);
      // Call Customize to show dialog now
      CToolBarCtrl tb = rbi.hwndChild;
      tb.Customize();
      return 0;
   }

   LRESULT OnToolbarDropDown(int /*idCtrl*/, LPNMHDR pnmh, BOOL& /*bHandled*/)
   {
      LPNMTOOLBAR lptb = (LPNMTOOLBAR) pnmh;
      CToolBarCtrl tb = lptb->hdr.hwndFrom;
      RECT rcItem;
      tb.GetItemRect(tb.CommandToIndex(lptb->iItem), &rcItem);
      POINT pt = { rcItem.left, rcItem.bottom };
      tb.ClientToScreen(&pt);
      // Display the "File" menu - just for fun...
      CMenuHandle menu = m_CmdBar.m_hMenu;
      CMenuHandle submenu = menu.GetSubMenu(0);
      m_CmdBar.TrackPopupMenu(submenu, TPM_LEFTALIGN | TPM_RIGHTBUTTON, pt.x, pt.y);
      return TBDDRET_DEFAULT;
   }

   LRESULT OnViewToolBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      static BOOL bVisible = TRUE;   // initially visible
      bVisible = !bVisible;
      CReBarCtrl rebar = m_hWndToolBar;
      int nBandIndex = rebar.IdToIndex(ATL_IDW_BAND_FIRST + 1);   // toolbar is 2nd added band
      rebar.ShowBand(nBandIndex, bVisible);
      UISetCheck(ID_VIEW_TOOLBAR, bVisible);
      UpdateLayout();
      return 0;
   }
   LRESULT OnViewStatusBar(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      BOOL bVisible = !::IsWindowVisible(m_hWndStatusBar);
      ::ShowWindow(m_hWndStatusBar, bVisible ? SW_SHOWNOACTIVATE : SW_HIDE);
      UISetCheck(ID_VIEW_STATUS_BAR, bVisible);
      UpdateLayout();
      return 0;
   }

   LRESULT OnAppKeyboard(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      CKeyboardDlg dlg(m_CmdBar.GetMenu(), m_hAccel, &m_accel.m_hAccel);
      dlg.DoModal();
      // TODO: Save new accelerator-table somewhere (ie. registry)
      //       so we can restore it again next time...
      return 0;
   }

   LRESULT OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
   {
      CAboutDlg dlg;
      dlg.DoModal();
      return 0;
   }
};


#endif // !defined(AFX_MAINFRM_H__8D2936ED_9E84_4EEE_92DA_4DDE7CC73914__INCLUDED_)
