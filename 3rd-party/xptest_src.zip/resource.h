//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XpTest.rc
//
#define IDC_ASSIGN                      3
#define IDC_REMOVE                      4
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MDICHILD                    129
#define IDD_SOLUTIONEXPLORER            201
#define IDR_SOLUTIONEXPLORER            202
#define IDD_PROPERTYVIEW                202
#define IDR_CLASSVIEW                   203
#define IDB_FOLDERS                     204
#define IDB_FOLDERVIEW                  205
#define IDR_PROPERTYVIEW                206
#define IDB_AUTOVIEWS                   207
#define IDD_PREFS1                      208
#define IDB_OPTIONSTREE                 208
#define IDD_PREFS2                      209
#define IDD_OPTIONS                     210
#define IDD_KEYBOARD                    211
#define IDC_TOOLBAR                     1000
#define IDC_TAB                         1001
#define IDC_COMBO                       1002
#define IDC_LIST                        1003
#define IDC_TITLE                       1004
#define IDC_FRAME                       1005
#define IDC_DESCRIPTION                 1006
#define IDC_TREE                        1008
#define IDC_PLACEHOLDER                 1009
#define IDC_DEFAULT_KEY                 1013
#define IDC_CURRENT_KEY                 1014
#define IDC_NEW_KEY                     1015
#define ID_VIEW_VIEW1                   32773
#define ID_BUTTON32774                  32774
#define ID_BUTTON32775                  32775
#define ID_BUTTON32776                  32776
#define ID_BUTTON32777                  32777
#define ID_TOOLS_RUNSCRIPT              32778
#define ID_TOOLS_RUNMACRO               32779
#define ID_VIEW_VIEW2                   32780
#define ID_TOOLS_OPTIONS                32781
#define ID_TOOLS_CUSTOMIZE              32782
#define IDS_NEW                         32783
#define IDS_OPEN                        32784
#define IDS_RUNMACRO                    32785
#define ID_APP_KEYBOARD                 32786
#define IDS_SB_PANE1                    57608
#define IDS_SB_PANE2                    57610

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        211
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
