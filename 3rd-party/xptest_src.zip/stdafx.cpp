// stdafx.cpp : source file that includes just the standard includes
//	MdiTest3.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#if (_ATL_VER < 0x0700)
#include <atlimpl.cpp>
#endif //(_ATL_VER < 0x0700)

#if (_MSC_VER >= 1300)
#pragma comment(linker, "/MANIFEST:NO")
#endif // (_MSC_VER > 1200)
